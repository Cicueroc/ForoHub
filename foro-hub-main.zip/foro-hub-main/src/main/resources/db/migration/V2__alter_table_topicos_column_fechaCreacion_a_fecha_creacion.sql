ALTER TABLE topicos
CHANGE COLUMN fechaCreacion fecha_creacion DATETIME NOT NULL;