package Api_ForoHub.domain.topico;

public record DatosActualizarTopico(
         String titulo,
         String mensaje,
         String nombreCurso,
         String categoriaCurso
) {
}
