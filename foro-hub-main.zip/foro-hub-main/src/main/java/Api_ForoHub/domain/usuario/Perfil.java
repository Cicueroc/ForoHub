package Api_ForoHub.domain.usuario;

public enum Perfil {
    ADMIN,
    USER
}
