package Api_ForoHub.infra.security;

public record DatosTokenJWT(
        String token
) {
}
